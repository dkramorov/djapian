/** @file
 * @brief Xapian::ProbEWeight class - probabilistic query expansion.
 */
/* Copyright (C) 2013 Aarsh Shah
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see
 * <https://www.gnu.org/licenses/>.
 */

#include <config.h>

#include "expandweight.h"
#include <cmath>

using namespace std;

namespace Xapian {
namespace Internal {

double
ProbEWeight::get_weight() const
{
    double reldocs_without_term = get_rsize() - stats.rtermfreq;
    double num = (stats.rtermfreq + 0.5) *
		 (get_dbsize() - stats.termfreq - reldocs_without_term + 0.5);
    double denom = (stats.termfreq - stats.rtermfreq + 0.5) *
		   (reldocs_without_term + 0.5);
    double tw = log(num / denom);
    return stats.multiplier * tw;
}

}
}
