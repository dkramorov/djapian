%{
/* python/extracomments.i: Custom written documentation comments.
 *
 * Copyright (C) 2007 Lemur Consulting Ltd
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see
 * <https://www.gnu.org/licenses/>.
 */
%}

/* Override any incorrect, missing or unhelpful documentation comments here. */

%feature("docstring") Xapian::MSet::get_hit "Get an item from the MSet.

The supplied index is relative to the start of the MSet, not the absolute rank
of the item. ";
